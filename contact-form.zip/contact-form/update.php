
<?php 
require_once('../../../wp-load.php');
class plugin{
function plugin_up(){
	 global $wpdb;
	 $id=$_POST["id"];
   $wpdb->query("UPDATE  apni_table SET status=1 WHERE id='$id'");
   
   ?><script type="text/javascript">window.location = "http://192.168.10.132/dharmendra/wordpress/wp-admin/admin.php?page=my-super-awesome-plugin";</script><?php
}

}
$ob=new plugin();
$ob->plugin_up();
?>