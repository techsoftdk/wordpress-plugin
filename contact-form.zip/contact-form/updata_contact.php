<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script>
$(document).ready(function(){
       $(".click3").click(function(x){ 
	       x.preventDefault();
	    $.ajax({
           type: "POST",
           url: "http://192.168.10.132/dharmendra/wordpress/wp-content/plugins/contact-form/update.php",
           data: {id:id},
           success: function(data)
           {
		   
		   }
		   });
		 });
		 });
</script>
	<form>
<div class="form-group">
    <label for="email">Name:</label>
    <input type="email" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="email">Subject:</label>
    <input type="email" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="email">Massege:</label>
    <input type="email" class="form-control" id="email">
  </div>
  </form>