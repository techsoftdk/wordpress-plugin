<?php 
/*
Plugin Name: Technical-form-page
Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
Description: A brief description of the Plugin.
Version: The Plugin's Version Number, e.g.: 1.0
Author: Dharmendra
Author URI: http://URI_Of_The_Plugin_Author
License: A "Slug" license name e.g. GPL2
.
Any other notes about the plugin go here
.
*/
?>
<?php
session_start();
Class my_plugin
{
    
 public function __construct()
 {
        add_action( 'admin_menu', array($this, 'setup_admin_menu') );
      	register_activation_hook( __FILE__, array( $this, 'create_table' ) );
	    register_deactivation_hook( __FILE__, array( $this, 'drop_table' ) );
		add_shortcode('contact_by', array($this, 'tera_function'));
	    global $wpdb;
			$name = $_POST['name'];
			$email = $_POST['email'];
			$subject = $_POST['subject'];
			$message = $_POST['message'];
			if(isset($_POST["submit"]))
			{
			$ok=$wpdb->insert( "apni_table", array(
			"name" =>$name,
			"email" => $email,
			"subject" => $subject,
			"msg" => $message));
			$_SESSION['message'] ="<div class='alert alert-success'>
    <strong>Success!</strong> This alert box could indicate a successful or positive action.
  </div>";
?><script type="text/javascript">window.location = "http://192.168.10.132/dharmendra/wordpress/"</script><?php

			 }
 }
 
    public function setup_admin_menu()
	{
        add_object_page( 'My contact-form', 'Contact-form', 'activate_plugins', 'my-super-awesome-plugin', array($this, 'mera_function') );
    
    }
   
 public function create_table()
 {
   global $wpdb;
  $tblname = 'apni_table';
  $sql = "CREATE TABLE IF NOT EXISTS $tblname ( ";
  $sql .= "  `id`  int(11)   NOT NULL auto_increment, ";
  $sql .= "  `name`  varchar(100)   NOT NULL ,";
  $sql .= "  `email`  varchar(100)   NOT NULL ,";
  $sql .= "  `subject`  varchar(100)   NOT NULL ,";
  $sql .= "  `msg`  varchar(100)   NOT NULL ,";
  $sql .= "  `pincode`  int(128)   NOT NULL, ";
  $sql .= "  PRIMARY KEY `order_id` (`id`) "; 
  $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ; ";
  require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
  dbDelta($sql);
 }
 
 public function drop_table()
 {	 
  global $wpdb;
	$sql = "DROP TABLE IF EXISTS apni_table";
	$wpdb->query($sql);
 }
 
 public function mera_function()
 {
$path=plugin_dir_path( __FILE__ );
		return include_once($path . 'view/mera_function.php' );
  }

	public function tera_function()
	{
		$path=plugin_dir_path( __FILE__ );
		return include_once($path . 'view/form.php' );
	}
 
}
$obj = new my_plugin();
$obj->create_table();
?>