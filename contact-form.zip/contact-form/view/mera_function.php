<?php
//	$logo = '<img src="' . plugins_url( 'images/logo.png', __FILE__ ) . '">';
//return $logo;
	?>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.4/css/jquery.dataTables.min.css">

  <script type="text/javascript">
    $(document).ready(function () {
	$('#table_id').DataTable({});
	
       $(".click").click(function(x){ 
	       x.preventDefault();
var id=$(this).attr("id");
if(!confirm('Are you sure to delete')){
return false;
}
	    $.ajax({
           type: "POST",
           url: "http://192.168.10.132/dharmendra/wordpress/wp-content/plugins/contact-form/update.php",
           data: {id:id},
           success: function(data)
           {
			  window.location = "http://192.168.10.132/dharmendra/wordpress/wp-admin/admin.php?page=my-super-awesome-plugin"; 		    }
         });
		 });
$(".click1").click(function(x){
	 x.preventDefault();
var id=$(this).attr("id");


$.ajax({
           type: "POST",
           url: "http://192.168.10.132/dharmendra/wordpress/wp-content/plugins/contact-form/view.php",
           data: {id:id},
           success: function(data)
           {
 		     var dec=$.parseJSON(data);
    $("#t1").html(dec.name);
      $("#t2").html(dec.email);
      $("#t3").html(dec.subject);
      $("#t4").html(dec.massege);
	  $("#popap").fadeIn();
           }
         });
		 });  
$("#cl").click(function(){
	$("#popap").hide();
});	 

	   });
</script>
	<div class="wrap">
<h1>Your Plugin Name </h1>
<table id="table_id" class="display table">
    <thead>
       <tr>
        		<th>Name</th>
        		<th>Email</th>
        		<th>Subject</th>       	
        		<th>massege</th> 
				<th>Action</th>
        	</tr>
    </thead>
    <tbody>
	<?php
    global $wpdb;
    $result = $wpdb->get_results ( "SELECT * FROM apni_table where status=0" );
    foreach ( $result as $print )   {
    ?>
    <tr>
    <td><?php echo $print->name;?></td>
    <td><?php echo $print->email;?></td>
    <td><?php echo $print->subject;?></td>
    <td><?php echo $print->msg;?></td>
	<th><button class="click" type="button"  id="<?php echo $print->id;?>">delete </button>
	<button class="click1" type="button" id="<?php echo $print->id;?>"> view </button></tr>
    
    <?php }
  ?>      
        
    </tbody>
</table>
	
</div>
<div id="popap"  style=" display:none;background:rgba(0, 0, 0, 0.72); position: fixed;left: 0;top: 0;z-index: 9999999;width: 100%;height: 100%;bottom: 0px;">
<div class="container-fluid">
<div class="row">
<div class="col-sm-3"></div>
<div class="col-sm-6">
<div id="user_view" style="box-shadow: 10px 10px grey; height: 400px; margin-top:100px; background-color: white;">
<table class="table table-responsive table-borderd">
<tr>
	<th>Name</th>

	<th id="t1"></th>
</tr>
<tr>
<th>Email</th>
<th id="t2"></th>
</tr>
<tr>
<th>Subject</th>
<th id="t3"></th>
</tr>
<tr>
	<th>Massege</th>
	<th id="t4"></th>
</tr>
</table>
<button id="cl" style="    position: absolute;
    left: 645px;
    top: 500px;"type="button" class="btn">&times;</div>
</div>
<div class="col-sm-3"></div>

</div>
</div>

</div>
</div>