<?php 
require_once('../../../wp-load.php');
class view{
function plugin_view(){
	 global $wpdb;
	 $id=$_POST["id"];
 $result = $wpdb->get_results ( "SELECT * FROM apni_table where id='$id'");
$json = array();    
    foreach ( $result as $print )   {
$json["name"]=$print->name;
$json["email"]=$print->email;
$json["subject"]=$print->subject;
$json["massege"]=$print->msg;
echo json_encode($json);
 
   }  
	
}}
$obj=new view();
$obj->plugin_view();
?>